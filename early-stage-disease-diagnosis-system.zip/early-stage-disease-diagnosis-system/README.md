A project to detect symptoms of various diseases by analyzing finger nails using image processing. 
Training is performed using a dataset comprising of images of finger nails of about 279 individuals. 
Machine Learning is used to classify the images on the basis of color and textures and gives the probable cause for the same.

